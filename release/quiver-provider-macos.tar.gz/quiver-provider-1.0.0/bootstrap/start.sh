#!/bin/bash
cd "$(dirname "$0")/.."
./scripts/start-network.sh
